import UIKit

extension String {

    func textThatFitBrute(width: CGFloat, height: CGFloat,
                     font: UIFont, trailingText: String,
                     moreText: String) -> (String, Bool) {
        let _height = self.height(withConstrainedWidth: width, font: font)
        if _height <= height { return (self, false) }

        var text = ""
        for index in 0...self.count-1 {
            let trimText = self.substring(to: index) + trailingText
            let newText = trimText + moreText
            let newHeight = newText.height(withConstrainedWidth: width, font: font)
            if newHeight <= height {
                text = trimText
                continue
            }
            return (text, true)
        }
        return (self, false)
    }
    
    func textThatFitBinary(width: CGFloat, height: CGFloat,
                     font: UIFont, trailingText: String,
                     moreText: String) -> (String, Bool) {
        let _height = self.height(withConstrainedWidth: width, font: font)
        if _height <= height { return (self, false) }

        var end: Int = self.utf16.count - 1
        var begin: Int = 0
        while abs(end - begin) > 1 {
            let mid = (end + begin) / 2
            let subText = self.substring(to: mid) + trailingText + moreText
            if subText.height(withConstrainedWidth: width, font: font) <= height {
                begin = mid
            } else {
                end = mid
            }
        }
        let truncatedText = self.substring(to: begin) + trailingText
        return (truncatedText, true)
    }
    
    func height(withConstrainedWidth width: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: width, height: .greatestFiniteMagnitude)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)

        return ceil(boundingBox.height)
    }
    
    func substring(to: Int) -> String {
        let toIndex = index(from: to)
        return String(self[...toIndex])
    }
    
    func index(from: Int) -> Index {
        return self.index(startIndex, offsetBy: from)
    }
}

var str = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque nisi mi, pulvinar ac ante nec, ullamcorper rhoncus augue. In rutrum sem in ipsum semper porta. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Quisque eleifend est a ex euismod facilisis. Vivamus egestas in dolor a varius. Praesent vitae lacus cursus, malesuada nisi vel, feugiat velit. Donec efficitur, dolor sit amet vestibulum luctus, tellus ligula venenatis augue, eu viverra nulla magna vitae dui. Donec ut ligula eu magna vehicula tincidunt at sit amet tortor. Suspendisse sodales facilisis dui, eu tempor eros. Curabitur convallis ut felis ullamcorper varius. Mauris vulputate orci purus, dignissim semper turpis molestie quis. In auctor laoreet dictum. Sed venenatis velit diam, a sodales sapien lobortis ut."

var start = DispatchTime.now()
str.textThatFitBrute(width: 375, height: 50, font: UIFont.systemFont(ofSize: 12), trailingText: "...", moreText: "Xem thêm")
var end = DispatchTime.now()
var nanoTime = end.uptimeNanoseconds - start.uptimeNanoseconds
var timeInterval = Double(nanoTime) / 1_000_000_000
print("Time by brute: \(timeInterval)")

start = DispatchTime.now()
str.textThatFitBinary(width: 375, height: 50, font: UIFont.systemFont(ofSize: 12), trailingText: "...", moreText: "Xem thêm")
end = DispatchTime.now()
nanoTime = end.uptimeNanoseconds - start.uptimeNanoseconds
timeInterval = Double(nanoTime) / 1_000_000_000
print("Time by binarysearch: \(timeInterval)")
